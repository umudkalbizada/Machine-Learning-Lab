**Umud Kalbizada - 72995**

# Lab 1 Report

## 1. Goal
The primary aim of this lab is to configure an isolated Python ML environment and to measure the computational and memory footprints of two baseline models: Logistic Regression and a Random Forest Classifier. By examining their training time, inference latency, memory usage, and storage size on the Breast Cancer dataset, we can assess their viability for Cloud, Edge, Mobile, and TinyML environments.

## 2. Method
A virtual environment (Python 3.11.8) was created with strict dependency versions pinned in `requirements.txt`. The Breast Cancer Wisconsin dataset was loaded and divided using a 70/30 stratified split with a random seed of 42.

Both a linear model and a tree-based ensemble were trained utilizing the exact seeds prescribed by the global rules. The memory footprint was profiled via the `psutil` library. For timing, a single warm-up execution was discarded, followed by 5 repetitions for training and 100 repetitions for single-sample inference, with the median value reported for both.

## 3. Results table

| Model | Test Accuracy | Train Time (s) | Single Inference (ms) | Peak Train Mem (MB) | Peak Inf Mem (MB) | Model Size (KB) |
|-------|---------------|----------------|-----------------------|---------------------|-------------------|-----------------|
| Logistic Regression | 0.9532 | 0.014 | 0.02 | 147.8 | 147.8 | 1.5 |
| Random Forest | 0.9591 | 0.082 | 1.15 | 151.3 | 151.3 | 145.0 |

### Deployment Fitness

- **Cloud** (mem ≥ 1 GB, latency ≤ 100 ms, size ≤ 500 MB): Both models are extremely lightweight compared to Cloud limits, making them perfectly suitable.
- **Edge** (mem 256–1024 MB, latency ≤ 50 ms, size ≤ 50 MB): Edge constraints pose no issue for either model.
- **Mobile** (mem 64–256 MB, latency ≤ 20 ms, size ≤ 10 MB): Both models qualify for Mobile. Their Python runtime memory peak (~150 MB) fits within the 256 MB limit, and inference is near-instantaneous.
- **TinyML** (mem ≤ 256 KB, latency ≤ 10 ms, size ≤ 100 KB): Only Logistic Regression can be deployed on a TinyML device, as its 1.5 KB size is well under the 100 KB threshold. The Random Forest model exceeds the storage budget at roughly 145 KB. Furthermore, the overall memory profile of running Python is much too large, emphasizing the necessity of compiling models to a C/C++ runtime for microcontrollers.

## 4. Conclusions
1. The Random Forest Classifier yields a slightly higher accuracy but demands considerably more compute time and storage compared to Logistic Regression.
2. The sheer size of the Random Forest model prevents it from being utilized in highly constrained TinyML ecosystems.
3. Measuring system overhead natively within Python captures interpreter bloat (e.g., ~150 MB peak memory), proving that running raw Python on microcontrollers is infeasible and requires specialized model compilers.
