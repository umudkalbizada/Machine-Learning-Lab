import sys
import pkg_resources

def check_env():
    out_f = '../results/versions.txt'
    req_f = '../../requirements.txt'
    
    with open(out_f, 'w') as f_out:
        f_out.write(f"Python: {sys.version}\n")
        
        with open(req_f, 'r') as f_in:
            for l in f_in:
                if '==' in l:
                    pkg = l.split('==')[0].strip()
                    try:
                        v = pkg_resources.get_distribution(pkg).version
                        f_out.write(f"{pkg}: {v}\n")
                    except pkg_resources.DistributionNotFound:
                        f_out.write(f"{pkg}: NOT FOUND\n")

if __name__ == '__main__':
    check_env()
