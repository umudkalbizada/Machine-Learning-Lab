import os
import time
import random
import numpy as np
import pandas as pd
import psutil
import joblib
import torch

from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

def fix_randomness():
    """Ensure reproducibility by fixing all required seeds."""
    random.seed(42)
    np.random.seed(42)
    torch.manual_seed(42)
    torch.cuda.manual_seed_all(42)

def profile_training_performance(mdl, x_tr, y_tr):
    # Warmup
    mdl.fit(x_tr, y_tr)
    
    time_records = []
    p = psutil.Process(os.getpid())
    peak_rss = 0
    
    for _ in range(5):
        t_start = time.perf_counter()
        mdl.fit(x_tr, y_tr)
        t_end = time.perf_counter()
        time_records.append(t_end - t_start)
        
        rss = p.memory_info().rss
        if rss > peak_rss:
            peak_rss = rss
            
    return np.median(time_records), peak_rss

def profile_inference_performance(mdl, x_inf):
    # Warmup
    mdl.predict(x_inf)
    
    time_records = []
    p = psutil.Process(os.getpid())
    peak_rss = 0
    
    for _ in range(100):
        t_start = time.perf_counter()
        mdl.predict(x_inf)
        t_end = time.perf_counter()
        time_records.append(t_end - t_start)
        
        rss = p.memory_info().rss
        if rss > peak_rss:
            peak_rss = rss
            
    return np.median(time_records), peak_rss

def execute_lab():
    fix_randomness()
    
    data_x, data_y = load_breast_cancer(return_X_y=True)
    x_tr, x_te, y_tr, y_te = train_test_split(
        data_x, data_y, test_size=0.3, stratify=data_y, random_state=42
    )
    
    baseline_models = {
        'LogisticRegression': LogisticRegression(max_iter=1000, random_state=42),
        'RandomForest': RandomForestClassifier(n_estimators=100, random_state=42)
    }
    
    res_dir = '../results'
    if not os.path.exists(res_dir):
        os.makedirs(res_dir)
        
    accuracy_log = []
    metrics_log = []
    
    for mdl_name, mdl in baseline_models.items():
        # Test Accuracy
        mdl.fit(x_tr, y_tr)
        predictions = mdl.predict(x_te)
        accuracy = accuracy_score(y_te, predictions)
        accuracy_log.append({'Model': mdl_name, 'Test Accuracy': f"{accuracy:.4f}"})
        
        # Training Metrics
        tr_time, tr_mem = profile_training_performance(mdl, x_tr, y_tr)
        
        # Inference Metrics (1 sample)
        x_single = x_te[0:1]
        inf_time, inf_mem = profile_inference_performance(mdl, x_single)
        
        # Serialization & Size
        dump_file = os.path.join(res_dir, f"{mdl_name.lower()}_model.joblib")
        joblib.dump(mdl, dump_file)
        
        bytes_size = os.path.getsize(dump_file)
        kb_size = bytes_size / 1024.0
        
        metrics_log.append({
            'Model': mdl_name,
            'Train Time (s)': tr_time,
            'Train Mem (MB)': tr_mem / (1024 * 1024),
            'Inf Time (s)': inf_time,
            'Inf Mem (MB)': inf_mem / (1024 * 1024),
            'Size (Bytes)': bytes_size,
            'Size (KB)': kb_size
        })
        
    pd.DataFrame(accuracy_log).to_csv(os.path.join(res_dir, 'baseline_accuracy.csv'), index=False)
    pd.DataFrame(metrics_log).to_csv(os.path.join(res_dir, 'system_costs.csv'), index=False)
    
    print("Lab completed successfully.")

if __name__ == "__main__":
    execute_lab()
